﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Marshrutizator
{
    public partial class Form1 : Form
    {
        Router ob;

        public Form1()
        {
            InitializeComponent();
            ob = new Router();
        }

        public void ReadFromFile(string filename)
        {
            StreamReader reader = new StreamReader(filename);
            string line = null;
            line = reader.ReadLine();
            string[] lines = line.Split('=');
            int n = 0;
            int k = 0;
            n = Convert.ToInt32(lines[1]);
            line = reader.ReadLine();
            lines = line.Split('=');
            k = Convert.ToInt32(lines[1]);            
            numericUpDown3.Value = n;
            numericUpDown4.Value = k;
            InitDataGridView();
            for (int i = 0; i < n; i++)
            {
                line = reader.ReadLine();
                lines = line.Split(' ');
                for (int j = 0; j < n; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = lines[j];
                }
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ReadFromFile(openFileDialog1.FileName);
            }
            else
            {
                MessageBox.Show("File not selected", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void doneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(numericUpDown1.Value);
            int b = Convert.ToInt32(numericUpDown2.Value);
            Init();
            try
            {                
                textBox1.Text = ob.FindRout(a, b);
            }
            catch (Exception)
            {
                textBox1.Text = a + " abonentdan " + b + " abonentga borish mumkin emas";
            }
        }

        public void Init()
        {
            int n = (int)numericUpDown3.Value;
            int k = (int)numericUpDown4.Value;
            bool[][] matr = new bool[n][];
            for(int i=0;i<n;i++)
            {
                matr[i] = new bool[n];
            }

            for(int i=0;i<n;i++)
            {
                for(int j=0;j<n;j++)
                {
                    if (dataGridView1.Rows[i].Cells[j].Value.Equals("0")) matr[i][j] = false;
                    else matr[i][j] = true;
                }
            }

            ob.N = n;
            ob.K = k;
            ob.Matritsa = matr;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InitDataGridView();
        }

        public void InitDataGridView()
        {
            int n = (int)numericUpDown3.Value;
            dataGridView1.RowCount = n;
            dataGridView1.ColumnCount = n;
            numericUpDown1.Maximum = n;
            numericUpDown2.Maximum = n;

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = "0";
                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
