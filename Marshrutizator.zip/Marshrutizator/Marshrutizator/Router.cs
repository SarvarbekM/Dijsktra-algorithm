﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marshrutizator
{
    public class Router
    {
        private int n;
        private int k;
        private bool[][] matritsa;        

        public int N
        {
            get { return n; }
            set { n = value; }
        }
        public int K
        {
            get { return k; }
            set { k = value; }
        }
        public bool[][] Matritsa
        {
            get { return matritsa; }
            set { matritsa = value; }
        }

        public string FindRout(int aAbonent,int bAbonent)
        {
            Graph graph = new Graph();
            for(int i=1;i<=n;i++)
            {
                char vertex = (char)(i+48);
                Dictionary<char, int> dictionary = new Dictionary<char, int>();
                for(int j=1;j<=n;j++)
                {
                    if(matritsa[i-1][j-1])
                    {
                        dictionary.Add((char)(j+48), 1);
                    }
                }
                if(dictionary.Count!=0)
                {
                    graph.add_vertex(vertex, dictionary);
                }
            }

            List<char> listchar = graph.shortest_path((char)(aAbonent+48), (char)(bAbonent+48));
            string answer = aAbonent.ToString()+" -> ";

            for(int i=listchar.ToArray().Length-1;i>=0;i--)
            {
                answer += listchar.ToArray()[i];
                if (i != 0) answer += " -> ";
            }
            return answer;            
        }
    }
}
